
Merchant Navy Courses - Ready-to-upload site
Files:
- index.html

How to publish on GitHub Pages (quick):
1. Create a GitHub account at https://github.com (if you don't have one).
2. Create a new repository (name it like merchant-navy-courses).
3. Upload all files from this folder to the repository (you can drag & drop on the GitHub web UI).
4. In the repository -> Settings -> Pages, set the source branch to 'main' (or 'master') and root folder '/'. Save.
5. Your site will be available at https://{username}.github.io/{repository-name}/ within a few minutes.

If you want, I can also provide step-by-step screenshots for publishing.
